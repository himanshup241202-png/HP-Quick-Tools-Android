# HP Quick Tools — Galaxy Store Android Project

This project wraps the supplied HP Quick Tools web app in a native Android WebView container.
The original HTML files are stored under `app/src/main/assets/HP-Quick-Tools/`.

## Included
- All supplied HP Quick Tools web pages and tool descriptions.
- Android application ID: `com.hpquicktools.app`
- App name: HP Quick Tools
- Target SDK: 35
- 64-bit capable Android app (standard Java/WebView build).
- Android file picker support for web `<input type=file>`.
- JavaScript, DOM storage and local asset loading enabled.
- Back button navigates WebView history.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select **Build > Generate App Bundles or APKs > Generate APKs**.
4. For a store release, create/select a release signing key and build the **release** variant.

Typical output:
`app/build/outputs/apk/release/app-release.apk`

## Galaxy Store
For publishing, use Samsung Seller Portal and follow its current app metadata, binary, signing, privacy and policy requirements. A signed release APK/AAB is required; do not upload the unsigned debug APK.

## Important
The project is prepared for building, but the release artifact must be signed with the developer's own keystore. Keep that keystore and passwords private and backed up.

# HP Quick Tools - no custom rules required for the current WebView wrapper.

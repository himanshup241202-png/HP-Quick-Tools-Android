# HP Quick Tools — GitHub Actions build

This project is prepared for a phone-only GitHub Actions build.

## Build from your phone
1. Create a GitHub repository.
2. Upload the **contents of this project folder** to the repository (do not upload only the ZIP as the project).
3. Open **Actions** → **Build HP Quick Tools Android** → **Run workflow**.
4. When it finishes, open the run and download **hp-quick-tools-android-build**.
5. That artifact contains a release APK, debug APK, and release AAB.

## Signed Galaxy Store build
For Galaxy Store distribution, use your own release keystore and keep it safe for future updates.

Create these GitHub repository secrets:
- `ANDROID_KEYSTORE_BASE64` — Base64 text of your `.jks`/`.keystore`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Then run **Build signed Galaxy Store release**. It creates a signed release APK and AAB.

**Never commit the keystore or passwords to the repository.**

## Bug fixes in this build
- **Image Compress download:** canvas/blob downloads are sent through a native Android download bridge instead of `ACTION_VIEW` on a `blob:` URL, preventing the app from closing/crashing. Files are saved under `Downloads/HP Quick Tools`.
- **Remove Background AI:** the bundled website is served through `WebViewAssetLoader` at an HTTPS-like app origin so the external ES-module AI library can load correctly in Android WebView. AI is configured for CPU mode for better WebView/device compatibility.
- **Ads preserved:** the existing ad scripts/placements were not removed.
- **All 14 tools, privacy page, terms, about/contact pages and sitemap are preserved.

# Gradle / GitHub Build Note

This package includes `gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.properties`.
The GitHub Actions workflow also supports the one-ZIP upload flow: it can extract the uploaded ZIP automatically, locate the Android project, and build Debug APK, Release APK, and Galaxy Store AAB.


Kotlin duplicate-class fix: Gradle resolution is pinned to Kotlin stdlib/jdk7/jdk8 1.8.22 to avoid mixed Kotlin runtime versions.

@echo off
REM HP Quick Tools GitHub-friendly Gradle launcher.
gradle %*

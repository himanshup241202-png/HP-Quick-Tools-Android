# HP Quick Tools Icon

The HP Quick Tools tools-style icon is included in the Android project.

- Android launcher icon: `app/src/main/res/drawable/ic_launcher.png`
- Galaxy Store asset: `store-assets/HP-Quick-Tools-icon-512.png`
- High-resolution store asset: `store-assets/HP-Quick-Tools-icon-1024.png`

The app manifest points to `@drawable/ic_launcher`, so the icon is used by the Android app build.
